# Project by File as Database

---
**How to run:**

1. Configure config.php file
2. Run command: **`php -S localhost:8080`** (HOST and PORT need to be same in config.php file)
3. Follow the link.

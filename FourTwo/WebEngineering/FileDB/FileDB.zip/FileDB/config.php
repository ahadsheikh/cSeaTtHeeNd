<?php
$PORT = 4022;
$BASE_URL = 'http://localhost:'.$PORT;
$DB_PATH = 'db.json';
$BASE_DIR = __DIR__;